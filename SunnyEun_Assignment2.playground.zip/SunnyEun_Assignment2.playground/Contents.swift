//: Playground - noun: a place where people can play

import UIKit



// Sunny Eun's Assignment 2: Exercises in Swift (Playgrounds)

// 1. Write a function that receives an Integer and returns a Boolean.
//    True if the integer is even, false otherwise.

func isEven(_ num: Int) -> Bool {
    if num % 2 == 0 {
        return true
    } else {
        return false
    }
}
print(isEven(7))



// 2-1. Write a Planet class. Use Object Oriented programming concepts such as Inheritance.

class Planet {
    var gravity: Double = 0
    var radius: String // Q. How can I add a thousand sepearator? (I Could not figure out, so changed Int to String)
    var orbitalPeriod: String
    var howFarFromTheSun: Double = 0
    var name: String
    
    init(name: String, radius: String, orbitalPeriod: String) {
        self.name = name
        self.radius = radius
        self.orbitalPeriod = orbitalPeriod
    }
    
    // Brief Desription
    func briefDescription() -> String {
        return "\(self.name)'s Gravity [\(gravity) m/s²], Radius [\(self.radius) mi], Orbital Period [\(self.orbitalPeriod) days], Distance from the Sun [\(howFarFromTheSun) million mi]."
    }
    
    // Size Comparison
    func sizeComparison() -> String {
        if radius < "3,959" { // The Earth's radius
            return "\(self.name) is smaller than the Earth."
        } else {
            return "\(self.name) is larger than the Earth."
        }
    }
    
    // Movement
    func moveingPlanet(_ x: Int, _ y: Int) {
        print("\(self.name) is moving to \(x) (x-axis) and \(y) (y-axis).")
    }
}


// 2-2. Also, write some code showing how you’d use it,
// Examples: print statistics about the planet, calculate the distance between two planets,
// make the planet move and report the changes.

// Brief Desription Results
let planet1 = Planet(name: "Venus", radius: "3,760", orbitalPeriod: "225")
planet1.gravity = 24.79
planet1.howFarFromTheSun = 67.24
print(planet1.briefDescription())

let planet2 = Planet(name: "Mars", radius: "2,106", orbitalPeriod: "687")
planet2.gravity = 3.711
planet2.howFarFromTheSun = 141.6
print(planet2.briefDescription())

let planet3 = Planet(name: "Jupiter", radius: "43,441", orbitalPeriod: "4,380")
planet3.gravity = 24.79
planet3.howFarFromTheSun = 483.8
print(planet3.briefDescription())

// Size Comparison Results
print(planet1.sizeComparison())
print(planet2.sizeComparison())
print(planet3.sizeComparison())


// Movement Results
planet1.moveingPlanet(180, 230)


// Distance Comparisons
if planet1.howFarFromTheSun < planet2.howFarFromTheSun && planet1.howFarFromTheSun < planet3.howFarFromTheSun {
    print("\(planet1.name) is the closest planet to the Sun.")
} else if planet1.howFarFromTheSun < planet2.howFarFromTheSun {
    print("\(planet1.name) is the closer to the Sun than \(planet2.name).")
} else if planet1.howFarFromTheSun < planet3.howFarFromTheSun {
    print("\(planet1.name) is the closer to the Sun than \(planet3.name).")
} else {
    print("\(planet1.name) is the furthest planet to the Sun.")
}





