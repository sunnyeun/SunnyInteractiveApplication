//: Playground - noun: a place where people can play

import UIKit


// Assignment1: A Swift Tour


// Simple Values (let vs. var)
// let = absolute value, var = changeable


var myVariable = 42
myVariable = 50
let myConstant = 42
// let = make a constant, var = assign a variable


let implicitInteger = 70
let implicitDouble = 70.0
let explicitDouble: Double = 70
// Whole number (one number) = Int, Fraction = Double


let label = "The width is "
let width = 94
let widthLabel = label + String(width) ///Is it impossible to print different type at once?
print(widthLabel)
// To convert a value to a different type, explicitly make an instance of the desired type


let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples."
let fruitSummary = "I have \(apples + oranges) pieces of fruit."
print(fruitSummary)
// simpler way to include values in strings. Use ackslash (\) before the parentheses


let quotation = """
I said "I have \(apples) apples."
And then I said "I have \(apples + oranges) pieces of fruits."
"""
print(quotation)
// Use """ for strings that take up multiple lines


var shoppingList = ["catfish", "water", "tulips", "blue paint"]
shoppingList[1] = "bottle of water" // Replace the first item's name
print(shoppingList)
// Arrays and dictionaries using []


var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic",
]
occupations["Jayne"] = "Public Relations" // Add the item, or change its name
print(occupations)


let emptyArray = [String]()
let emptyDictionary = [String: Float]()
// Create an empty array and dictionary


shoppingList = []
occupations = [:]
// If type information can be inferred, write an empty array as [] and empty dictionary as [:]



//(Use if and switch to make conditional and use for-in, while, and repeat-while to make loops)

let individualScores = [75, 43, 103, 87, 12]
var teamScore = 0
for score in individualScores { // The for-in loop iterates over collections of items, such as array
    if score > 50 { // In an if statement, the conditional must be a Boolean (true/false)
        teamScore += 3
    } else {
        teamScore += 1
    }
}
print(teamScore)


var optionalString: String? = "Hello"
print(optionalString == nil)
// If the optional value is nil, the conditional is false


var optionalName: String? = "John Appleseed"
var greeting = "Hello!"
if let name = optionalName {
    greeting = "Hello \(name)"
}
print(greeting)
// ? = optional value


let nickName: String? = nil // If the optional value is nil, the conditional is false
let fullName: String = "John Appleseed"
let informationGreeting = "Hi \(nickName ?? fullName)"
print(informationGreeting)
// Provide a default value using the ?? operator.
// If the optional value is missing, the default vaue is used instead.

// Q. Is it possible to have multiple defaults?


let vegetable = "red pepper"
switch vegetable {
case "celery":
    print("Add some rasins and make ants on a log.")
case "cucumber", "watercress":
    print("That would make a good tea sandwich.")
case let x where x.hasSuffix("pepper"):
    print("Is it a spicy \(x)?")
default:
    print("Everything tastes good in soup.")
}
// Use switch for comparing multiple cases


var n = 2
while n < 100 {
    n *= 2
}
print(n)

var m = 2
repeat {
    m *= 2
} while m < 100
print(m)


var total = 0
for i in 0..<4 {
    total += i
}
print(total)
// To keep an index in a loop by using ..< to make a range of indexes



// Fuctions and Closures
// Use func to declare a function and call it by following its name with a list of arguments in parentheses.
// Use -> to separate the parameter names and types from the fucntion's return type.

func greet(person: String, day: String) -> String {
    return "Hello \(person), today is \(day)."
}
print(greet(person: "Bob", day: "Tuesday"))


func greet2(_ person: String, on day: String) -> String {
    return "Hello \(person), today is \(day)."
}
print(greet2("Bob", on: "Wednesday"))
// Underscore (_) = no specific parameter name


func returnFifteen() -> Int {
    var y = 10
    func add() {
        y += 5
    }
    add()
    return y // Q. Why "add()" and "return y" is necessary? The result is still correct without them.
}
returnFifteen()
// Nested function


func makeIncrementer() -> ((Int) -> Int) {
    func addOne(number: Int) -> Int {
        return 1 + number
    }
    return addOne
}
var increment = makeIncrementer()
increment(7)


func hasAnyMatches(list: [Int], condition: (Int) -> Bool) -> Bool {
    for item in list {
        if condition(item) {
            return true
        }
    }
    return false
}
func lessThanTen(number: Int) -> Bool {
    return number < 10
}
var numbers = [20, 19, 7, 12]
hasAnyMatches(list: numbers, condition: lessThanTen)



// Objects and Classes\

class Shape {
    var numberOfSides = 0
    func simpleDescription() -> String {
        return "A shape with \(numberOfSides) sides."
    }
}

let shape = Shape()
shape.numberOfSides = 3
print(shape.simpleDescription())

class Animal {
    var xMove = 0
    var yMove = 0
    func AnimalMovement() -> String {
        return "An animal moves \(xMove) and \(yMove) meters."
    }
}

let animal = Animal()
animal.xMove = 20
animal.yMove = 40
print(animal.AnimalMovement())



class NamedShape {
    var numberOfSides: Int = 0
    var name: String
    
    init(name: String) {
        self.name = name // init = an initializer to set up the inital value for each stored property
    }
    
    func simpleDescription() -> String {
        return "A shape with \(numberOfSides) sides."
    }
}




// Enumerations and Structures
// Use enum to create an enumeration.

enum Suit {
    case spades, hearts, diamonds, clubs
    func simpleDescription() -> String {
        switch self { // Q. Why is it "self" and why is the switch inside of enum?
        case .spades:
            return "spades"
        case .hearts:
            return "hearts"
        case .diamonds:
            return "diamonds"
        case .clubs:
            return "clubs"
        }
    }
}
let hearts = Suit.hearts
let heartsDescription = hearts.simpleDescription()



